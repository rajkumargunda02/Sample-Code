﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
         

        public static void Main(string[] args)
        {
            string typeOfRequest= args[0];
            string fileName = args[1];
           if(typeOfRequest== "-v" || typeOfRequest == "--v" || typeOfRequest == "/v"|| typeOfRequest == "--version")
            {
                FileDetails getVersion = new FileDetails();
                Console.WriteLine(getVersion.Version(fileName));
                Console.ReadLine();
            }
            else if (typeOfRequest == "-s" || typeOfRequest == "--s" || typeOfRequest == "/s" || typeOfRequest == "--size")
            {
                FileDetails getSize = new FileDetails();
                Console.WriteLine(getSize.Size(fileName));

                Console.ReadLine();
            }
        }
    }
}
